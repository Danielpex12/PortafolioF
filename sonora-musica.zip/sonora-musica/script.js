/* ================================================
   SONORA — script.js
   Piano con Web Audio API + efectos interactivos
   ================================================ */

'use strict';

// ============ CURSOR PERSONALIZADO ============
const cursor      = document.getElementById('cursor');
const cursorTrail = document.getElementById('cursorTrail');
let mouseX = 0, mouseY = 0;

document.addEventListener('mousemove', e => {
  mouseX = e.clientX; mouseY = e.clientY;
  cursor.style.left      = mouseX + 'px';
  cursor.style.top       = mouseY + 'px';
  setTimeout(() => {
    cursorTrail.style.left = mouseX + 'px';
    cursorTrail.style.top  = mouseY + 'px';
  }, 80);
});

document.querySelectorAll('a, button, .piano-key, .genero-card, .galeria-item').forEach(el => {
  el.addEventListener('mouseenter', () => {
    cursor.style.transform = 'translate(-50%,-50%) scale(2)';
    cursorTrail.style.transform = 'translate(-50%,-50%) scale(1.5)';
    cursorTrail.style.borderColor = 'rgba(255,45,85,0.6)';
  });
  el.addEventListener('mouseleave', () => {
    cursor.style.transform = 'translate(-50%,-50%) scale(1)';
    cursorTrail.style.transform = 'translate(-50%,-50%) scale(1)';
    cursorTrail.style.borderColor = 'rgba(0,245,255,0.4)';
  });
});

// ============ PARTÍCULAS DE FONDO ============
const canvas = document.getElementById('particleCanvas');
const ctx    = canvas.getContext('2d');
let particles = [];
let W, H;

function resizeCanvas() {
  W = canvas.width  = window.innerWidth;
  H = canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

class Particle {
  constructor() { this.reset(); }
  reset() {
    this.x   = Math.random() * W;
    this.y   = Math.random() * H;
    this.r   = Math.random() * 1.5 + 0.3;
    this.vx  = (Math.random() - 0.5) * 0.4;
    this.vy  = (Math.random() - 0.5) * 0.4 - 0.1;
    this.alpha = Math.random() * 0.5 + 0.1;
    const hues = ['#ff2d55', '#00f5ff', '#7c3aed', '#f59e0b', '#10b981'];
    this.color = hues[Math.floor(Math.random() * hues.length)];
  }
  update() {
    this.x += this.vx; this.y += this.vy;
    if (this.x < 0 || this.x > W || this.y < 0 || this.y > H) this.reset();
  }
  draw() {
    ctx.save();
    ctx.globalAlpha = this.alpha;
    ctx.fillStyle   = this.color;
    ctx.shadowBlur  = 6;
    ctx.shadowColor = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

for (let i = 0; i < 120; i++) particles.push(new Particle());

function animateParticles() {
  ctx.clearRect(0, 0, W, H);
  particles.forEach(p => { p.update(); p.draw(); });
  requestAnimationFrame(animateParticles);
}
animateParticles();

// ============ WAVEFORM ANIMADO HERO ============
const wavePath = document.getElementById('wavePath');
let waveT = 0;
function animateHeroWave() {
  waveT += 0.02;
  let d = 'M0,60';
  for (let x = 0; x <= 1200; x += 10) {
    const y = 60
      + Math.sin(x * 0.01 + waveT)     * 25
      + Math.sin(x * 0.02 - waveT*1.3) * 15
      + Math.sin(x * 0.007 + waveT*0.7)* 10;
    d += ` L${x},${y}`;
  }
  if (wavePath) wavePath.setAttribute('d', d);
  requestAnimationFrame(animateHeroWave);
}
animateHeroWave();

// ============ SCROLL ANIMATIONS ============
const observerOpts = { threshold: 0.15, rootMargin: '0px 0px -60px 0px' };
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      if (e.target.classList.contains('timeline-item')) observer.unobserve(e.target);
    }
  });
}, observerOpts);

document.querySelectorAll('.timeline-item').forEach(el => observer.observe(el));

// ============ GÉNERO CARDS — efecto de luz ============
document.querySelectorAll('.genero-card').forEach(card => {
  card.addEventListener('mousemove', e => {
    const r = card.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width  * 100).toFixed(1);
    const y = ((e.clientY - r.top)  / r.height * 100).toFixed(1);
    card.querySelector('.genero-hover-fx').style.setProperty('--mx', x + '%');
    card.querySelector('.genero-hover-fx').style.setProperty('--my', y + '%');
  });
});

// ============ NAVEGACIÓN — highlight activo ============
const sections = document.querySelectorAll('section[id], header[id]');
const navLinks  = document.querySelectorAll('.nav-links a');
const navObserver = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      navLinks.forEach(l => l.classList.remove('active'));
      const link = document.querySelector(`.nav-links a[href="#${e.target.id}"]`);
      if (link) link.classList.add('active');
    }
  });
}, { threshold: 0.4 });
sections.forEach(s => navObserver.observe(s));

// ============ PIANO — WEB AUDIO API ============

// Contexto de audio
let audioCtx = null;
let masterGain, reverbNode, dryGain, wetGain;
let reverbBuffer = null;
let octave   = 4;
let volume   = 0.7;
let reverbAmt = 0.3;
let waveType  = 'sine';

const activeOscillators = {};

// Notas y frecuencias de referencia (octava 4)
const NOTE_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const NOTE_DISPLAY = {
  'C':'Do', 'C#':'Do#', 'D':'Re', 'D#':'Re#', 'E':'Mi',
  'F':'Fa', 'F#':'Fa#', 'G':'Sol', 'G#':'Sol#', 'A':'La', 'A#':'La#', 'B':'Si'
};

// Frecuencia a partir de nota y octava (A4 = 440 Hz)
function noteFrequency(note, oct) {
  const semitone = NOTE_NAMES.indexOf(note);
  const n = (oct - 4) * 12 + semitone - 9; // offset from A4
  return 440 * Math.pow(2, n / 12);
}

// Crear contexto de audio al primer clic
function ensureAudioContext() {
  if (audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();

  masterGain = audioCtx.createGain();
  masterGain.gain.value = volume;

  // Reverb sencillo con ConvolverNode generado sintéticamente
  reverbNode = audioCtx.createConvolver();
  createReverbBuffer();

  dryGain = audioCtx.createGain();
  wetGain = audioCtx.createGain();
  dryGain.gain.value = 1 - reverbAmt;
  wetGain.gain.value = reverbAmt;

  masterGain.connect(dryGain);
  masterGain.connect(reverbNode);
  reverbNode.connect(wetGain);
  dryGain.connect(audioCtx.destination);
  wetGain.connect(audioCtx.destination);

  // Analizador para visualizador
  analyser = audioCtx.createAnalyser();
  analyser.fftSize = 256;
  analyserData = new Uint8Array(analyser.frequencyBinCount);
  masterGain.connect(analyser);
  drawVisualizer();
}

function createReverbBuffer() {
  const sampleRate = audioCtx.sampleRate;
  const length = sampleRate * 2.5;
  const decay  = 3.0;
  const buffer = audioCtx.createBuffer(2, length, sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const data = buffer.getChannelData(ch);
    for (let i = 0; i < length; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
    }
  }
  reverbNode.buffer = buffer;
}

// Tocar nota
function playNote(note, oct) {
  ensureAudioContext();
  const key = note + oct;
  if (activeOscillators[key]) return;

  const freq = noteFrequency(note, oct);
  const osc  = audioCtx.createOscillator();
  const env  = audioCtx.createGain();

  osc.type = waveType;
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

  // Segundo oscilador para armonía (octava superior, más suave)
  const osc2 = audioCtx.createOscillator();
  osc2.type = waveType;
  osc2.frequency.setValueAtTime(freq * 2, audioCtx.currentTime);
  const env2 = audioCtx.createGain();
  env2.gain.setValueAtTime(0.12, audioCtx.currentTime);

  // Envelope (ADSR simplificado)
  env.gain.setValueAtTime(0, audioCtx.currentTime);
  env.gain.linearRampToValueAtTime(0.7, audioCtx.currentTime + 0.01);   // Attack
  env.gain.exponentialRampToValueAtTime(0.4, audioCtx.currentTime + 0.15); // Decay → Sustain

  osc.connect(env);
  osc2.connect(env2);
  env.connect(masterGain);
  env2.connect(masterGain);
  osc.start();
  osc2.start();

  activeOscillators[key] = { osc, osc2, env, env2, freq };

  // Mostrar nota en display
  document.getElementById('displayNote').textContent = NOTE_DISPLAY[note] || note;
  document.getElementById('displayFreq').textContent = `Frecuencia: ${freq.toFixed(2)} Hz`;

  // Añadir partícula de sonido
  spawnNoteParticle(freq);
}

// Soltar nota
function releaseNote(note, oct) {
  const key = note + oct;
  const active = activeOscillators[key];
  if (!active) return;
  const { osc, osc2, env, env2 } = active;
  const t = audioCtx.currentTime;
  env.gain.cancelScheduledValues(t);
  env.gain.setValueAtTime(env.gain.value, t);
  env.gain.exponentialRampToValueAtTime(0.0001, t + 0.5); // Release
  env2.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
  osc.stop(t + 0.6);
  osc2.stop(t + 0.6);
  delete activeOscillators[key];

  setTimeout(() => {
    document.getElementById('displayNote').textContent = '—';
    document.getElementById('displayFreq').textContent = 'Frecuencia: —';
  }, 600);
}

// ============ CONSTRUIR EL TECLADO ============
// Distribución de una octava: 7 blancas, 5 negras
// C  D  E  F  G  A  B  con negras C# D# F# G# A#
const WHITE_KEYS  = ['C','D','E','F','G','A','B'];
const BLACK_KEYS  = ['C#','D#',null,'F#','G#','A#',null]; // null = no hay negra

const KB_WHITE_MAP = { 'a':'C','s':'D','d':'E','f':'F','g':'G','h':'A','j':'B' };
const KB_BLACK_MAP = { 'w':'C#','e':'D#','t':'F#','y':'G#','u':'A#' };

function buildPiano() {
  const container = document.getElementById('pianoKeys');
  container.innerHTML = '';

  const keysToRender = 14; // 2 octavas
  const startOct = octave;

  for (let o = 0; o < 2; o++) {
    const oct = startOct + o;
    const octaveGroup = document.createElement('div');
    octaveGroup.style.cssText = 'position:relative; display:flex;';

    WHITE_KEYS.forEach((note, i) => {
      const key = document.createElement('div');
      key.className = 'piano-key white';
      key.dataset.note = note;
      key.dataset.oct  = oct;

      // Label del teclado (solo primera octava)
      const kbKeys = Object.entries(KB_WHITE_MAP);
      const kbEntry = o === 0 ? kbKeys[i] : null;

      key.innerHTML = `
        <span class="key-note">${note}${oct}</span>
        ${kbEntry ? `<span class="key-label">${kbEntry[0].toUpperCase()}</span>` : ''}
      `;

      key.addEventListener('mousedown', () => {
        playNote(note, oct);
        key.classList.add('active');
      });
      key.addEventListener('mouseup',   () => { releaseNote(note, oct); key.classList.remove('active'); });
      key.addEventListener('mouseleave', () => { releaseNote(note, oct); key.classList.remove('active'); });
      key.addEventListener('touchstart', e => { e.preventDefault(); playNote(note, oct); key.classList.add('active'); }, { passive: false });
      key.addEventListener('touchend',   e => { e.preventDefault(); releaseNote(note, oct); key.classList.remove('active'); }, { passive: false });

      octaveGroup.appendChild(key);
    });

    // Teclas negras
    BLACK_KEYS.forEach((note, i) => {
      if (!note) return;
      const black = document.createElement('div');
      black.className = 'piano-key black';
      black.dataset.note = note;
      black.dataset.oct  = oct;

      const kbBlackEntries = Object.entries(KB_BLACK_MAP);
      const blackNotes = ['C#','D#','F#','G#','A#'];
      const kbEntry = o === 0 ? kbBlackEntries[blackNotes.indexOf(note)] : null;

      // Posición horizontal (entre teclas blancas)
      const positions = { 'C#':34, 'D#':82, 'F#':178, 'G#':226, 'A#':274 };
      black.style.left = (positions[note] + o * 336) + 'px';

      black.innerHTML = kbEntry ? `<span class="key-label">${kbEntry[0].toUpperCase()}</span>` : '';

      black.addEventListener('mousedown', e => { e.stopPropagation(); playNote(note, oct); black.classList.add('active'); });
      black.addEventListener('mouseup',   e => { releaseNote(note, oct); black.classList.remove('active'); });
      black.addEventListener('mouseleave',() => { releaseNote(note, oct); black.classList.remove('active'); });
      black.addEventListener('touchstart', e => { e.preventDefault(); e.stopPropagation(); playNote(note, oct); black.classList.add('active'); }, { passive: false });
      black.addEventListener('touchend',   e => { e.preventDefault(); releaseNote(note, oct); black.classList.remove('active'); }, { passive: false });

      octaveGroup.appendChild(black);
    });

    container.appendChild(octaveGroup);
  }
}
buildPiano();

// ============ TECLADO DE COMPUTADORA ============
const pressedKeys = new Set();

document.addEventListener('keydown', e => {
  if (pressedKeys.has(e.key.toLowerCase())) return;
  pressedKeys.add(e.key.toLowerCase());

  const key = e.key.toLowerCase();
  let note, oct;

  if (KB_WHITE_MAP[key]) {
    note = KB_WHITE_MAP[key]; oct = octave;
  } else if (KB_BLACK_MAP[key]) {
    note = KB_BLACK_MAP[key]; oct = octave;
  } else return;

  playNote(note, oct);

  // Resaltar tecla visualmente
  const keyEls = document.querySelectorAll(`.piano-key[data-note="${note}"][data-oct="${oct}"]`);
  keyEls.forEach(k => k.classList.add('active'));
});

document.addEventListener('keyup', e => {
  pressedKeys.delete(e.key.toLowerCase());
  const key = e.key.toLowerCase();
  let note;
  if (KB_WHITE_MAP[key])      note = KB_WHITE_MAP[key];
  else if (KB_BLACK_MAP[key]) note = KB_BLACK_MAP[key];
  else return;

  releaseNote(note, octave);
  const keyEls = document.querySelectorAll(`.piano-key[data-note="${note}"]`);
  keyEls.forEach(k => k.classList.remove('active'));
});

// ============ CONTROLES ============
document.getElementById('octaveDown').addEventListener('click', () => {
  if (octave > 1) { octave--; document.getElementById('octaveDisplay').textContent = octave; buildPiano(); }
});
document.getElementById('octaveUp').addEventListener('click', () => {
  if (octave < 7) { octave++; document.getElementById('octaveDisplay').textContent = octave; buildPiano(); }
});

document.getElementById('volumeSlider').addEventListener('input', e => {
  volume = e.target.value / 100;
  if (masterGain) masterGain.gain.value = volume;
});

document.getElementById('reverbSlider').addEventListener('input', e => {
  reverbAmt = e.target.value / 100;
  if (dryGain) dryGain.gain.value = 1 - reverbAmt;
  if (wetGain) wetGain.gain.value = reverbAmt;
});

document.getElementById('waveformSelect').addEventListener('change', e => {
  waveType = e.target.value;
});

// ============ VISUALIZADOR DE AUDIO ============
let analyser, analyserData;
const vizCanvas = document.getElementById('pianoVisualizer');
const vizCtx    = vizCanvas.getContext('2d');

function drawVisualizer() {
  const W = vizCanvas.offsetWidth;
  const H = vizCanvas.offsetHeight;
  vizCanvas.width  = W;
  vizCanvas.height = H;

  function loop() {
    requestAnimationFrame(loop);
    vizCtx.clearRect(0, 0, W, H);

    if (!analyser) return;
    analyser.getByteFrequencyData(analyserData);

    const barW = W / analyserData.length * 2.5;
    let x = 0;
    for (let i = 0; i < analyserData.length; i++) {
      const barH = analyserData[i] / 255 * H;
      const hue  = (i / analyserData.length) * 180;
      vizCtx.fillStyle = `hsl(${hue + 180}, 100%, 60%)`;
      vizCtx.shadowBlur   = 8;
      vizCtx.shadowColor  = `hsl(${hue + 180}, 100%, 60%)`;
      vizCtx.fillRect(x, H - barH, barW - 1, barH);
      x += barW;
    }
  }
  loop();
}
drawVisualizer();

// ============ PARTÍCULAS DE NOTA ============
const noteParticles = [];
const noteParticleCanvas = document.createElement('canvas');
noteParticleCanvas.style.cssText = `
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  pointer-events: none; z-index: 50;
`;
document.body.appendChild(noteParticleCanvas);
const nCtx = noteParticleCanvas.getContext('2d');
noteParticleCanvas.width  = window.innerWidth;
noteParticleCanvas.height = window.innerHeight;
window.addEventListener('resize', () => {
  noteParticleCanvas.width  = window.innerWidth;
  noteParticleCanvas.height = window.innerHeight;
});

class NoteParticle {
  constructor(freq) {
    const piano = document.getElementById('pianoKeys');
    const rect  = piano ? piano.getBoundingClientRect() : { left: W/2, top: H/2, width: 0 };
    this.x  = rect.left + Math.random() * (rect.width || 200);
    this.y  = rect.top  - 10;
    this.vx = (Math.random() - 0.5) * 4;
    this.vy = -(Math.random() * 4 + 2);
    this.r  = Math.random() * 6 + 3;
    this.life = 1;
    this.decay = Math.random() * 0.02 + 0.015;
    const hue = ((freq - 220) / 880) * 240;
    this.color = `hsl(${hue}, 100%, 70%)`;
    this.text = ['♩','♪','♫','♬','🎵','🎶'][Math.floor(Math.random() * 6)];
    this.useText = Math.random() > 0.6;
    this.size = Math.random() * 12 + 10;
  }
  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += 0.05;
    this.life -= this.decay;
    this.r  *= 0.99;
  }
  draw(c) {
    c.save();
    c.globalAlpha = Math.max(0, this.life);
    if (this.useText) {
      c.font = `${this.size}px serif`;
      c.fillStyle = this.color;
      c.fillText(this.text, this.x, this.y);
    } else {
      c.fillStyle = this.color;
      c.shadowBlur  = 12;
      c.shadowColor = this.color;
      c.beginPath();
      c.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      c.fill();
    }
    c.restore();
  }
}

function spawnNoteParticle(freq) {
  for (let i = 0; i < 6; i++) {
    noteParticles.push(new NoteParticle(freq));
  }
}

function animateNoteParticles() {
  nCtx.clearRect(0, 0, noteParticleCanvas.width, noteParticleCanvas.height);
  for (let i = noteParticles.length - 1; i >= 0; i--) {
    noteParticles[i].update();
    noteParticles[i].draw(nCtx);
    if (noteParticles[i].life <= 0) noteParticles.splice(i, 1);
  }
  requestAnimationFrame(animateNoteParticles);
}
animateNoteParticles();

// ============ EFECTO RIPPLE EN CLICKS ============
document.addEventListener('click', e => {
  if (e.target.classList.contains('piano-key')) return;
  const ripple = document.createElement('div');
  ripple.style.cssText = `
    position: fixed;
    left: ${e.clientX}px; top: ${e.clientY}px;
    width: 4px; height: 4px;
    border-radius: 50%;
    border: 1px solid rgba(0,245,255,0.6);
    transform: translate(-50%,-50%);
    animation: rippleOut 0.8s ease-out forwards;
    pointer-events: none;
    z-index: 9000;
  `;
  document.body.appendChild(ripple);
  setTimeout(() => ripple.remove(), 800);
});

// Inyectar keyframe para ripple
const style = document.createElement('style');
style.textContent = `
  @keyframes rippleOut {
    to { transform: translate(-50%,-50%) scale(30); opacity: 0; }
  }
  .nav-links a.active { color: var(--white) !important; }
  .nav-links a.active::after { transform: scaleX(1) !important; }
`;
document.head.appendChild(style);

// ============ NAV: glassmorphism on scroll ============
window.addEventListener('scroll', () => {
  const nav = document.querySelector('.nav');
  nav.style.background = window.scrollY > 50
    ? 'rgba(8,8,16,0.95)'
    : 'rgba(8,8,16,0.7)';
});

// ============ ANIMACIÓN DE ENTRADA DE GALERÍA ============
const galObs = new IntersectionObserver(entries => {
  entries.forEach((e, i) => {
    if (e.isIntersecting) {
      setTimeout(() => {
        e.target.style.opacity = '1';
        e.target.style.transform = 'translateY(0)';
      }, i * 120);
      galObs.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.galeria-item').forEach(el => {
  el.style.opacity   = '0';
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  galObs.observe(el);
});

// ============ TARJETAS DE GÉNEROS — animación entrada ============
const genreObs = new IntersectionObserver(entries => {
  entries.forEach((e, idx) => {
    if (e.isIntersecting) {
      setTimeout(() => {
        e.target.style.opacity   = '1';
        e.target.style.transform = 'translateY(0) scale(1)';
      }, idx * 100);
      genreObs.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.genero-card').forEach(el => {
  el.style.opacity    = '0';
  el.style.transform  = 'translateY(40px) scale(0.97)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  genreObs.observe(el);
});

// ============ VINILO: parar animación si no está visible ============
const vinyl = document.querySelector('.vinyl-disc');
if (vinyl) {
  const vinylObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      vinyl.style.animationPlayState = e.isIntersecting ? 'running' : 'paused';
    });
  }, { threshold: 0.1 });
  vinylObs.observe(vinyl);
}

// ============ SECUENCIA DE DEMOSTRACIÓN ============
// Toca una pequeña melodía de bienvenida al cargar
window.addEventListener('load', () => {
  setTimeout(() => {
    const demo = [
      { note: 'C', delay: 0 },
      { note: 'E', delay: 250 },
      { note: 'G', delay: 500 },
      { note: 'C', delay: 750 },
    ];
    demo.forEach(({ note, delay }) => {
      setTimeout(() => {
        playNote(note, 5);
        setTimeout(() => releaseNote(note, 5), 300);
      }, delay);
    });
  }, 2000);
});

console.log('%cSONORA 🎵 Piano cargado con Web Audio API', 'color:#00f5ff;font-family:monospace;font-size:14px;');
console.log('%cTeclas blancas: A S D F G H J | Negras: W E T Y U', 'color:#ff2d55;font-family:monospace;font-size:11px;');
